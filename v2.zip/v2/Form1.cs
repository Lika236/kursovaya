using System;
using System.Data;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Collections.Generic;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        string connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\Автосалон.mdb;";
        public string UserRole { get; set; }
        public int? CurrentProfileID { get; set; }

        public Form1()
        {
            InitializeComponent();
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // ✅ Принудительно обновляем UI перед загрузкой
            Application.DoEvents();

            // Загружаем все данные
            LoadAllData();

            // ✅ Принудительно перерисовываем все таблицы
            dataGridView1.Refresh();
            dataGridView1.Update();
            dataGridView2.Refresh();
            dataGridView2.Update();
            dataGridView3.Refresh();
            dataGridView3.Update();

            // ✅ Если не админ - обновляем профиль
            if (CurrentProfileID.HasValue && UserRole != "admin")
            {
                LoadProfileData();
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {

            // 2. настройка видимости кнопок и вкладок по роли
            SetupUIByRole();

            // 3. настройка сеток таблиц
            SetupGrid(dataGridView1);
            SetupGrid(dataGridView2);
            SetupGrid(dataGridView3);

          

            // 4.загрузка всех данных
            LoadAllData();

            // 5. загрузка профиля
            if (UserRole == "admin")
            {
                lblWelcome.Text = "Панель Администратора";
        
            }
            else if (CurrentProfileID.HasValue)
            {
                LoadProfileData();
            }

            // скрыть вкладку Продажи от юзера
            if (UserRole == "user" && tabControl1.TabPages.Contains(tabPage3))
            {
                tabControl1.TabPages.Remove(tabPage3);
            }
        }

        private void SetupUIByRole()
        {
            // Вкладки
            tabControl1.TabPages["tabPage2"].Visible = (UserRole == "admin" || UserRole == "manager");
            tabControl1.TabPages["tabPage3"].Visible = (UserRole == "admin" || UserRole == "manager");

            // Кнопки машин
            btnAddCar.Visible = (UserRole == "manager" || UserRole == "admin");
            btnEditCar.Visible = (UserRole == "manager" || UserRole == "admin");
            btnDeleteCar.Visible = (UserRole == "manager" || UserRole == "admin");
            btnBookCar.Visible = (UserRole == "user");
            cmbPayment.Visible = (UserRole == "user");
            lblPaymentLabel.Visible = (UserRole == "user");

            // Кнопки менеджеров
            btnAddManager.Visible = (UserRole == "admin");
            btnDeleteManager.Visible = (UserRole == "admin");
            btnEditManager.Visible = (UserRole == "admin");

            // Кнопки продаж
            btnCompleteSale.Visible = (UserRole == "manager");
            btnApplySort.Visible = (UserRole == "admin");

            // скрытие текстбоксов не для админов
            if (txtSortName != null) txtSortName.Visible = (UserRole == "admin");
            if (txtSortMonth != null) txtSortMonth.Visible = (UserRole == "admin");
            if (txtSortYear != null) txtSortYear.Visible = (UserRole == "admin");

            // скрыть лейблы не для админов
            if (label4 != null) label4.Visible = (UserRole == "admin");
            if (label5 != null) label5.Visible = (UserRole == "admin");
            if (label6 != null) label6.Visible = (UserRole == "admin");
            
        }

     
        private void LoadAllData()
        {
          //машины
            string carFilter = "";

            if (UserRole == "user")
            {
                carFilter = " WHERE [Status] = 'Доступна'";
            }
            else if (UserRole == "manager" && CurrentProfileID.HasValue)
            {
                // Менеджер видит свои машины, исключая проданные проданные
                carFilter = " WHERE [AddedByManagerID] = " + CurrentProfileID.Value + " AND [Status] <> 'Продана'";
            }
            else
            {
                // Админ тоже не видит проданные 
                carFilter = " WHERE [Status] <> 'Продана'";
            }

            string sqlCars = "SELECT [CarID], [Marka], [Model], [God Vipyska], [Color], [Price], [Status], [AddedByManagerID] FROM [Car]" + carFilter;
            LoadTable(sqlCars, dataGridView1);

            // 2. МЕНЕДЖЕРЫ
            string sqlManagers = "SELECT [ManagerID], [Name manager], [Familiya], [Kontakt] FROM [Manager]";
            LoadTable(sqlManagers, dataGridView2);

            // 3. ПРОДАЖИ
            string sqlSales = "";
            if (UserRole == "manager" && CurrentProfileID.HasValue)
            {
                //  Менеджер видит только свои продажи 
                sqlSales = "SELECT [Prodazhi].[ProdazhID], [Prodazhi].[CarID], [Prodazhi].[ManagerID], " +
                           "[Car].[Marka] & ' ' & [Car].[Model] AS [Машина], " +
                           "[Klienty].[Imya] & ' ' & [Klienty].[Familiya] AS [Клиент], " +
                           "'Вы' AS [Менеджер], " +
                           "[Prodazhi].[Status], [Prodazhi].[PaymentMethod], " +
                           "IIF([Prodazhi].[Data prodazhi] IS NULL, '-', Format([Prodazhi].[Data prodazhi], 'dd.mm.yyyy')) AS [Data prodazhi] " +
                           "FROM (([Prodazhi] " +
                           "INNER JOIN [Car] ON [Prodazhi].[CarID] = [Car].[CarID]) " +
                           "INNER JOIN [Klienty] ON [Prodazhi].[KlientID] = [Klienty].[KlientID]) " +
                           "WHERE [Prodazhi].[ManagerID] = " + CurrentProfileID.Value +
                           " ORDER BY [Prodazhi].[Data prodazhi] DESC";
            }
            else
            {
                // Админ видит всё
                sqlSales = "SELECT [Prodazhi].[ProdazhID], [Prodazhi].[CarID], [Prodazhi].[ManagerID], " +
                           "[Car].[Marka] & ' ' & [Car].[Model] AS [Машина], " +
                           "[Klienty].[Imya] & ' ' & [Klienty].[Familiya] AS [Клиент], " +
                           "[Manager].[Name manager] & ' ' & [Manager].[Familiya] AS [Менеджер], " +
                           "[Prodazhi].[Status], [Prodazhi].[PaymentMethod], " +
                           "Format([Prodazhi].[Data prodazhi], 'dd.mm.yyyy') AS [Data prodazhi] " +
                           "FROM (([Prodazhi] " +
                           "INNER JOIN [Car] ON [Prodazhi].[CarID] = [Car].[CarID]) " +
                           "INNER JOIN [Klienty] ON [Prodazhi].[KlientID] = [Klienty].[KlientID]) " +
                           "INNER JOIN [Manager] ON [Prodazhi].[ManagerID] = [Manager].[ManagerID] " +
                           "ORDER BY [Prodazhi].[Data prodazhi] DESC";
            }
            LoadTable(sqlSales, dataGridView3);
        }

        private void LoadTable(string query, DataGridView grid)
        {
            try
            {
                grid.DataSource = null;
                grid.Columns.Clear();

                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    using (OleDbDataAdapter adapter = new OleDbDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        grid.DataSource = dt;
                    }
                }

                // Скрываем технические ID
                if (grid == dataGridView1)
                {
                    if (grid.Columns.Contains("CarID")) grid.Columns["CarID"].Visible = false;
                    if (grid.Columns.Contains("AddedByManagerID")) grid.Columns["AddedByManagerID"].Visible = false;
                }
                else if (grid == dataGridView2 && grid.Columns.Contains("ManagerID"))
                    grid.Columns["ManagerID"].Visible = false;
                else if (grid == dataGridView3)
                {
                    if (grid.Columns.Contains("ProdazhID")) grid.Columns["ProdazhID"].Visible = false;
                    if (grid.Columns.Contains("CarID")) grid.Columns["CarID"].Visible = false;
                    if (grid.Columns.Contains("ManagerID")) grid.Columns["ManagerID"].Visible = false;
                    if (grid.Columns.Contains("KlientID")) grid.Columns["KlientID"].Visible = false;
                    if (grid.Columns.Contains("AddedByManagerID")) grid.Columns["AddedByManagerID"].Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки:\n" + ex.Message, "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

      

        private void btnAddCar_Click(object sender, EventArgs e)
        {
            if (UserRole != "manager" && UserRole != "admin") return;
            if (!CurrentProfileID.HasValue) { MessageBox.Show("Ошибка профиля."); return; }

            string marka = ShowInputDialog("Марка:", "Новая машина");
            if (string.IsNullOrEmpty(marka)) return;
            string model = ShowInputDialog("Модель:", "Новая машина");
            if (string.IsNullOrEmpty(model)) return;
            string year = ShowInputDialog("Год:", "Новая машина", "2023");
            string color = ShowInputDialog("Цвет:", "Новая машина", "Белый");
            string price = ShowInputDialog("Цена:", "Новая машина", "1000000");

            try
            {
                using (var conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    string q = "INSERT INTO [Car] ([Marka], [Model], [God Vipyska], [Color], [Price], [AddedByManagerID], [Status]) " +
                               "VALUES (@m, @mod, @yr, @col, @pr, @mid, 'Доступна')";
                    using (var cmd = new OleDbCommand(q, conn))
                    {
                        cmd.Parameters.AddWithValue("@m", marka);
                        cmd.Parameters.AddWithValue("@mod", model);
                        cmd.Parameters.AddWithValue("@yr", year);
                        cmd.Parameters.AddWithValue("@col", color);
                        cmd.Parameters.AddWithValue("@pr", price);
                        cmd.Parameters.AddWithValue("@mid", CurrentProfileID.Value);
                        cmd.ExecuteNonQuery();
                    }
                }
                MessageBox.Show(" Машина добавлена!");
                LoadAllData();
            }
            catch (Exception ex) { MessageBox.Show("❌ Ошибка: " + ex.Message); }
        }

        private string ShowInputDialog(string prompt, string title, string defaultValue = "")
        {
            Form f = new Form { Width = 400, Height = 150, Text = title, FormBorderStyle = FormBorderStyle.FixedDialog, StartPosition = FormStartPosition.CenterScreen, MaximizeBox = false, MinimizeBox = false };
            Label lbl = new Label { Text = prompt, Left = 10, Top = 10, Width = 350 };
            TextBox txt = new TextBox { Left = 10, Top = 35, Width = 350, Text = defaultValue };
            Button btn = new Button { Text = "OK", Left = 150, Top = 70, Width = 75, DialogResult = DialogResult.OK };
            btn.Click += (s, e) => f.Close();
            f.Controls.Add(lbl); f.Controls.Add(txt); f.Controls.Add(btn); f.AcceptButton = btn;
            return f.ShowDialog() == DialogResult.OK ? txt.Text : "";
        }

        private void btnBookCar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0) { MessageBox.Show("Выберите машину!"); return; }
            if (!dataGridView1.Columns.Contains("CarID")) { MessageBox.Show("Ошибка CarID!"); return; }

            var cell = dataGridView1.SelectedRows[0].Cells["CarID"];
            if (cell.Value == null || cell.Value == DBNull.Value) { MessageBox.Show("CarID пуст!"); return; }

            int carId = Convert.ToInt32(cell.Value);
            string payment = cmbPayment.Text;
            if (string.IsNullOrEmpty(payment)) { MessageBox.Show("Выберите оплату!"); return; }
            if (!CurrentProfileID.HasValue) { MessageBox.Show("Ошибка профиля!"); return; }

            try
            {
                using (var conn = new OleDbConnection(connectionString))
                {
                    conn.Open();

                    // Проверка на активную бронь
                    string checkQ = "SELECT COUNT(*) FROM [Prodazhi] WHERE [KlientID] = @kid AND [Status] = 'Бронь'";
                    using (var cmd = new OleDbCommand(checkQ, conn))
                    {
                        cmd.Parameters.Add("@kid", OleDbType.Integer).Value = CurrentProfileID.Value;
                        if (Convert.ToInt32(cmd.ExecuteScalar()) > 0)
                        {
                            MessageBox.Show(" У вас уже есть бронь!");
                            return;
                        }
                    }

                    int mgrId = GetManagerIdForCar(carId);

                    // Создаем бронь
                    string insQ = "INSERT INTO [Prodazhi] ([CarID], [KlientID], [ManagerID], [Status], [PaymentMethod], [ReservationDate]) " +
                                  "VALUES (@cid, @kid, @mid, 'Бронь', @pay, @date)";
                    using (var cmd = new OleDbCommand(insQ, conn))
                    {
                        cmd.Parameters.Add("@cid", OleDbType.Integer).Value = carId;
                        cmd.Parameters.Add("@kid", OleDbType.Integer).Value = CurrentProfileID.Value;
                        cmd.Parameters.Add("@mid", OleDbType.Integer).Value = mgrId;
                        cmd.Parameters.Add("@pay", OleDbType.VarWChar).Value = payment;
                        cmd.Parameters.Add("@date", OleDbType.Date).Value = DateTime.Now;
                        cmd.ExecuteNonQuery();
                    }

                    // Меняем статус машины
                    using (var cmd = new OleDbCommand("UPDATE [Car] SET [Status] = 'Забронирована' WHERE [CarID] = @id", conn))
                    {
                        cmd.Parameters.Add("@id", OleDbType.Integer).Value = carId;
                        cmd.ExecuteNonQuery();
                    }
                }
                MessageBox.Show(" Забронировано!");
                LoadAllData();
            }
            catch (Exception ex) { MessageBox.Show(" Ошибка: " + ex.Message); }
        }





        private void btnEditCar_Click(object sender, EventArgs e)
        {
            if (UserRole != "manager" && UserRole != "admin") return;
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите машину для редактирования.");
                return;
            }

            var row = dataGridView1.SelectedRows[0];
            if (!TryGetCellInt(row, "CarID", out int carId)) return;

            string status = row.Cells["Status"]?.Value?.ToString() ?? "";
            if (status == "Продана")
            {
                MessageBox.Show("Нельзя редактировать проданную машину.");
                return;
            }

            if (UserRole == "manager" && CurrentProfileID.HasValue)
            {
                if (!TryGetCellInt(row, "AddedByManagerID", out int ownerId) || ownerId != CurrentProfileID.Value)
                {
                    MessageBox.Show("Вы можете редактировать только свои машины.");
                    return;
                }
            }

            string marka = ShowInputDialog("Марка:", "Редактировать машину", row.Cells["Marka"]?.Value?.ToString());
            if (string.IsNullOrEmpty(marka)) return;
            string model = ShowInputDialog("Модель:", "Редактировать машину", row.Cells["Model"]?.Value?.ToString());
            if (string.IsNullOrEmpty(model)) return;
            string year = ShowInputDialog("Год:", "Редактировать машину", row.Cells["God Vipyska"]?.Value?.ToString());
            string color = ShowInputDialog("Цвет:", "Редактировать машину", row.Cells["Color"]?.Value?.ToString());
            string price = ShowInputDialog("Цена:", "Редактировать машину", row.Cells["Price"]?.Value?.ToString());

            try
            {
                using (var conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    string q = "UPDATE [Car] SET [Marka]=@m, [Model]=@mod, [God Vipyska]=@yr, [Color]=@col, [Price]=@pr WHERE [CarID]=@id";
                    using (var cmd = new OleDbCommand(q, conn))
                    {
                        cmd.Parameters.AddWithValue("@m", marka);
                        cmd.Parameters.AddWithValue("@mod", model);
                        cmd.Parameters.AddWithValue("@yr", year);
                        cmd.Parameters.AddWithValue("@col", color);
                        cmd.Parameters.AddWithValue("@pr", price);
                        cmd.Parameters.Add("@id", OleDbType.Integer).Value = carId;
                        cmd.ExecuteNonQuery();
                    }
                }
                MessageBox.Show(" Машина обновлена!");
                LoadAllData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Ошибка: " + ex.Message);
            }
        }

        private void btnDeleteCar_Click(object sender, EventArgs e)
        {
            if (UserRole != "manager" && UserRole != "admin") return;
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите машину для удаления.", "Удаление", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var row = dataGridView1.SelectedRows[0];
            if (!TryGetCellInt(row, "CarID", out int carId)) return;

            string status = row.Cells["Status"]?.Value?.ToString() ?? "";
            if (status != "Доступна")
            {
                MessageBox.Show("Удалить можно только машину со статусом «Доступна».\n" +
                                "Забронированные и проданные автомобили удалять нельзя.",
                                "Удаление", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (UserRole == "manager" && CurrentProfileID.HasValue)
            {
                if (!TryGetCellInt(row, "AddedByManagerID", out int ownerId) || ownerId != CurrentProfileID.Value)
                {
                    MessageBox.Show("Вы можете удалять только свои машины.", "Удаление",
                                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            string carName = $"{row.Cells["Marka"]?.Value} {row.Cells["Model"]?.Value}".Trim();
            if (MessageBox.Show($"Удалить машину «{carName}»?\nДействие необратимо.",
                                "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            try
            {
                using (var conn = new OleDbConnection(connectionString))
                {
                    conn.Open();

                    string checkSales = "SELECT COUNT(*) FROM [Prodazhi] WHERE [CarID] = @cid AND [Status] IN ('Бронь', 'Завершена')";
                    using (var cmd = new OleDbCommand(checkSales, conn))
                    {
                        cmd.Parameters.Add("@cid", OleDbType.Integer).Value = carId;
                        if (Convert.ToInt32(cmd.ExecuteScalar()) > 0)
                        {
                            MessageBox.Show("Нельзя удалить: у машины есть активная или завершённая сделка.",
                                            "Удаление", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    using (var cmd = new OleDbCommand("DELETE FROM [Car] WHERE [CarID] = @id", conn))
                    {
                        cmd.Parameters.Add("@id", OleDbType.Integer).Value = carId;
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Машина удалена.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadAllData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка удаления: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Завершение сделки с проверками статуса и подтверждением
        private void btnCompleteSale_Click(object sender, EventArgs e)
        {
            if (dataGridView3.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите запись из таблицы продаж.", "Сделка",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!dataGridView3.Columns.Contains("ProdazhID") || !dataGridView3.Columns.Contains("CarID"))
            {
                MessageBox.Show("Ошибка: не найдены служебные колонки таблицы.", "Сделка",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var row = dataGridView3.SelectedRows[0];
            var prodIdCell = row.Cells["ProdazhID"];
            var carIdCell = row.Cells["CarID"];

            if (prodIdCell.Value == null || prodIdCell.Value == DBNull.Value)
            {
                MessageBox.Show("Эта машина ещё не забронирована.\nДождитесь, пока клиент оформит бронь.",
                                "Сделка", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (!TryGetCellInt(row, "CarID", out int carId)) return;
            int saleId = Convert.ToInt32(prodIdCell.Value);

            string status = row.Cells["Status"]?.Value?.ToString()?.Trim() ?? "";
            if (status == "Завершена")
            {
                MessageBox.Show("Эта сделка уже завершена.", "Сделка",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (status != "Бронь")
            {
                MessageBox.Show($"Завершить можно только бронь.\nТекущий статус: {status}",
                                "Сделка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (UserRole == "manager" && CurrentProfileID.HasValue && dataGridView3.Columns.Contains("ManagerID"))
            {
                if (!TryGetCellInt(row, "ManagerID", out int managerId) || managerId != CurrentProfileID.Value)
                {
                    MessageBox.Show("Вы можете завершать только свои сделки.", "Сделка",
                                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            string carName = dataGridView3.Columns.Contains("Машина") ? row.Cells["Машина"]?.Value?.ToString() : "автомобиль";
            string clientName = dataGridView3.Columns.Contains("Клиент") ? row.Cells["Клиент"]?.Value?.ToString() : "клиент";
            string payment = dataGridView3.Columns.Contains("PaymentMethod") ? row.Cells["PaymentMethod"]?.Value?.ToString() : "-";

            if (MessageBox.Show(
                    $"Завершить сделку?\n\nМашина: {carName}\nКлиент: {clientName}\nОплата: {payment}\nДата: {DateTime.Now:dd.MM.yyyy}",
                    "Подтверждение сделки", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            try
            {
                using (var conn = new OleDbConnection(connectionString))
                {
                    conn.Open();

                    string checkQ = "SELECT [Status] FROM [Prodazhi] WHERE [ProdazhID] = @sid";
                    using (var cmdCheck = new OleDbCommand(checkQ, conn))
                    {
                        cmdCheck.Parameters.Add("@sid", OleDbType.Integer).Value = saleId;
                        object dbStatus = cmdCheck.ExecuteScalar();
                        if (dbStatus == null || dbStatus == DBNull.Value)
                        {
                            MessageBox.Show($"Запись сделки ID={saleId} не найдена.", "Сделка",
                                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        if (dbStatus.ToString().Trim() == "Завершена")
                        {
                            MessageBox.Show("Сделка уже была завершена ранее.", "Сделка",
                                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadAllData();
                            return;
                        }
                    }

                    string q1 = "UPDATE [Prodazhi] SET [Status] = 'Завершена', [Data prodazhi] = @saleDate WHERE [ProdazhID] = @sid AND [Status] = 'Бронь'";
                    using (var cmd = new OleDbCommand(q1, conn))
                    {
                        cmd.Parameters.Add("@saleDate", OleDbType.Date).Value = DateTime.Now.Date;
                        cmd.Parameters.Add("@sid", OleDbType.Integer).Value = saleId;

                        if (cmd.ExecuteNonQuery() == 0)
                        {
                            MessageBox.Show("Не удалось завершить сделку. Возможно, статус уже изменился.",
                                            "Сделка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            LoadAllData();
                            return;
                        }
                    }

                    using (var cmd = new OleDbCommand("UPDATE [Car] SET [Status] = 'Продана' WHERE [CarID] = @cid", conn))
                    {
                        cmd.Parameters.Add("@cid", OleDbType.Integer).Value = carId;
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Сделка успешно завершена!", "Успех",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadAllData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Сделка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnApplySort_Click(object sender, EventArgs e)
        {
            if (UserRole != "admin") return;

            string nameFilter = txtSortName.Text.Trim();
            string monthText = txtSortMonth.Text.Trim();
            string yearText = txtSortYear.Text.Trim();

            string baseQ = "SELECT [Prodazhi].[ProdazhID], [Prodazhi].[CarID], [Prodazhi].[ManagerID], " +
                          "[Car].[Marka] & ' ' & [Car].[Model] AS [Машина], " +
                          "[Klienty].[Imya] & ' ' & [Klienty].[Familiya] AS [Клиент], " +
                          "[Manager].[Name manager] & ' ' & [Manager].[Familiya] AS [Менеджер], " +
                          "[Prodazhi].[Status], [Prodazhi].[PaymentMethod], " +
                          "Format([Prodazhi].[Data prodazhi], 'dd.mm.yyyy') AS [Data prodazhi] " +
                          "FROM (([Prodazhi] INNER JOIN [Car] ON [Prodazhi].[CarID] = [Car].[CarID]) " +
                          "INNER JOIN [Klienty] ON [Prodazhi].[KlientID] = [Klienty].[KlientID]) " +
                          "INNER JOIN [Manager] ON [Prodazhi].[ManagerID] = [Manager].[ManagerID] ";

            List<string> conditions = new List<string>();

            // поиск по бд
            if (!string.IsNullOrEmpty(nameFilter))
            {
                conditions.Add("INSTR([Manager].[Name manager] & ' ' & [Manager].[Familiya], @name) > 0");
            }

            if (!string.IsNullOrEmpty(monthText) && !string.IsNullOrEmpty(yearText))
            {
                try
                {
                    int m = Convert.ToInt32(monthText);
                    int y = Convert.ToInt32(yearText);
                    conditions.Add("Month([Prodazhi].[Data prodazhi]) = @month AND Year([Prodazhi].[Data prodazhi]) = @year");
                }
                catch
                {
                    MessageBox.Show("Месяц и Год должны быть числами!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            string whereClause = conditions.Count > 0 ? " WHERE " + string.Join(" AND ", conditions) : "";
            string finalQuery = baseQ + whereClause + " ORDER BY [Prodazhi].[Data prodazhi] DESC";

            try
            {
                using (var conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (var cmd = new OleDbCommand(finalQuery, conn))
                    {
                        if (!string.IsNullOrEmpty(nameFilter))
                            cmd.Parameters.AddWithValue("@name", nameFilter);

                        if (!string.IsNullOrEmpty(monthText) && !string.IsNullOrEmpty(yearText))
                        {
                            cmd.Parameters.AddWithValue("@month", Convert.ToInt32(monthText));
                            cmd.Parameters.AddWithValue("@year", Convert.ToInt32(yearText));
                        }

                        using (var adapter = new OleDbDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);
                            dataGridView3.DataSource = dt;
                        }
                    }
                }

                // Скрываем служебные колонки
                if (dataGridView3.Columns.Contains("ProdazhID")) dataGridView3.Columns["ProdazhID"].Visible = false;
                if (dataGridView3.Columns.Contains("CarID")) dataGridView3.Columns["CarID"].Visible = false;
                if (dataGridView3.Columns.Contains("ManagerID")) dataGridView3.Columns["ManagerID"].Visible = false;
                if (dataGridView3.Columns.Contains("KlientID")) dataGridView3.Columns["KlientID"].Visible = false;

                if (dataGridView3.Rows.Count == 0)
                    MessageBox.Show("Ничего не найдено по заданным критериям.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сортировки: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAddManager_Click(object sender, EventArgs e)
        {
            if (UserRole != "admin") return;

            string name = ShowInputDialog("Имя менеджера:", "Новый менеджер");
            if (string.IsNullOrEmpty(name)) return;
            string familiya = ShowInputDialog("Фамилия:", "Новый менеджер");
            if (string.IsNullOrEmpty(familiya)) return;
            string kontakt = ShowInputDialog("Контакт (телефон):", "Новый менеджер", "+7");

            try
            {
                using (var conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    string q = "INSERT INTO [Manager] ([Name manager], [Familiya], [Kontakt]) VALUES (@n, @f, @k)";
                    using (var cmd = new OleDbCommand(q, conn))
                    {
                        cmd.Parameters.Add("@n", OleDbType.VarWChar).Value = name;
                        cmd.Parameters.Add("@f", OleDbType.VarWChar).Value = familiya;
                        cmd.Parameters.Add("@k", OleDbType.VarWChar).Value = kontakt;
                        cmd.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Менеджер добавлен.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadAllData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEditManager_Click(object sender, EventArgs e)
        {
            if (UserRole != "admin") return;
            if (dataGridView2.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите менеджера.", "Изменение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!TryGetCellInt(dataGridView2.SelectedRows[0], "ManagerID", out int managerId)) return;

            var row = dataGridView2.SelectedRows[0];
            string name = ShowInputDialog("Имя:", "Изменить менеджера", row.Cells["Name manager"]?.Value?.ToString());
            if (string.IsNullOrEmpty(name)) return;
            string familiya = ShowInputDialog("Фамилия:", "Изменить менеджера", row.Cells["Familiya"]?.Value?.ToString());
            if (string.IsNullOrEmpty(familiya)) return;
            string kontakt = ShowInputDialog("Контакт:", "Изменить менеджера", row.Cells["Kontakt"]?.Value?.ToString());

            try
            {
                using (var conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    string q = "UPDATE [Manager] SET [Name manager]=@n, [Familiya]=@f, [Kontakt]=@k WHERE [ManagerID]=@id";
                    using (var cmd = new OleDbCommand(q, conn))
                    {
                        cmd.Parameters.Add("@n", OleDbType.VarWChar).Value = name;
                        cmd.Parameters.Add("@f", OleDbType.VarWChar).Value = familiya;
                        cmd.Parameters.Add("@k", OleDbType.VarWChar).Value = kontakt;
                        cmd.Parameters.Add("@id", OleDbType.Integer).Value = managerId;
                        cmd.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Данные менеджера обновлены.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadAllData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDeleteManager_Click(object sender, EventArgs e)
        {
            if (UserRole != "admin") return;
            if (dataGridView2.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите менеджера.", "Удаление", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!TryGetCellInt(dataGridView2.SelectedRows[0], "ManagerID", out int managerId)) return;

            string fullName = $"{dataGridView2.SelectedRows[0].Cells["Name manager"]?.Value} " +
                              $"{dataGridView2.SelectedRows[0].Cells["Familiya"]?.Value}".Trim();

            if (MessageBox.Show($"Удалить менеджера «{fullName}»?", "Подтверждение",
                                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            try
            {
                using (var conn = new OleDbConnection(connectionString))
                {
                    conn.Open();

                    string checkSales = "SELECT COUNT(*) FROM [Prodazhi] WHERE [ManagerID] = @id";
                    using (var cmd = new OleDbCommand(checkSales, conn))
                    {
                        cmd.Parameters.Add("@id", OleDbType.Integer).Value = managerId;
                        if (Convert.ToInt32(cmd.ExecuteScalar()) > 0)
                        {
                            MessageBox.Show("Нельзя удалить: у менеджера есть связанные сделки.",
                                            "Удаление", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    using (var cmd = new OleDbCommand("DELETE FROM [Manager] WHERE [ManagerID] = @id", conn))
                    {
                        cmd.Parameters.Add("@id", OleDbType.Integer).Value = managerId;
                        cmd.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Менеджер удалён.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadAllData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool TryGetCellInt(DataGridViewRow row, string columnName, out int value)
        {
            value = 0;
            if (!row.DataGridView.Columns.Contains(columnName))
            {
                MessageBox.Show($"Колонка «{columnName}» не найдена.", "Ошибка",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            object cellValue = row.Cells[columnName].Value;
            if (cellValue == null || cellValue == DBNull.Value)
            {
                MessageBox.Show($"Значение «{columnName}» пустое.", "Ошибка",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            value = Convert.ToInt32(cellValue);
            return true;
        }

        private int GetManagerIdForCar(int carId)
        {
            using (var conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                using (var cmd = new OleDbCommand("SELECT [AddedByManagerID] FROM [Car] WHERE [CarID]=@id", conn))
                {
                    cmd.Parameters.Add("@id", OleDbType.Integer).Value = carId;
                    var r = cmd.ExecuteScalar();
                    return r != null ? Convert.ToInt32(r) : 1;

                }
            }
        }

        private void SetupGrid(DataGridView grid)
        {
            grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grid.AllowUserToAddRows = false;
            grid.ReadOnly = true;
        }

        private void LoadProfileData()
        {
            if (UserRole == "admin") return;
            try
            {
                string tbl = UserRole == "user" ? "Klienty" : "Manager";
                string idF = UserRole == "user" ? "KlientID" : "ManagerID";
                string q = UserRole == "user"
                    ? "SELECT Imya, Familiya, Number, Email, Address FROM [" + tbl + "] WHERE [" + idF + "] = @id"
                    : "SELECT [Name manager], Familiya, Kontakt FROM [" + tbl + "] WHERE [" + idF + "] = @id";

                using (var conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (var cmd = new OleDbCommand(q, conn))
                    {
                        cmd.Parameters.Add("@id", OleDbType.Integer).Value = CurrentProfileID.Value;
                        using (var r = cmd.ExecuteReader())
                        {
                            if (r.Read())
                            {
                                if (UserRole == "user")
                                {
                                    txtImya.Text = r["Imya"]?.ToString() ?? "";
                                    txtFamiliya.Text = r["Familiya"]?.ToString() ?? "";
                                    txtPhone.Text = r["Number"]?.ToString() ?? "";
                                    txtEmail.Text = r["Email"]?.ToString() ?? "";
                                    txtAddress.Text = r["Address"]?.ToString() ?? "";
                                    lblWelcome.Text = "Профиль: " + r["Imya"] + " " + r["Familiya"];
                                }
                                else
                                {
                                    txtImya.Text = r["Name manager"]?.ToString() ?? "";
                                    txtFamiliya.Text = r["Familiya"]?.ToString() ?? "";
                                    txtPhone.Text = r["Kontakt"]?.ToString() ?? "";
                                    lblWelcome.Text = "Профиль: " + r["Name manager"] + " " + r["Familiya"];
                                    txtEmail.Visible = false;
                                    txtAddress.Visible = false;
                                    if (lblEmailLabel != null) lblEmailLabel.Visible = false;
                                    if (lblAddressLabel != null) lblAddressLabel.Visible = false;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show("Ошибка профиля: " + ex.Message); }
        }

        private void btnSaveProfile_Click(object sender, EventArgs e)
        {
            if (UserRole == "admin")
            {
                MessageBox.Show("У администратора нет редактируемого профиля.");
                return;
            }

            if (!CurrentProfileID.HasValue)
            {
                MessageBox.Show("Ошибка: профиль не загружен!");
                return;
            }

            try
            {
                string tableName = UserRole == "user" ? "Klienty" : "Manager";
                string idField = UserRole == "user" ? "KlientID" : "ManagerID";

                string query = UserRole == "user"
                    ? "UPDATE [" + tableName + "] SET Imya=@imya, Familiya=@familiya, Number=@phone, Email=@email, Address=@address WHERE [" + idField + "]=@id"
                    : "UPDATE [" + tableName + "] SET [Name manager]=@name, Familiya=@familiya, Kontakt=@phone WHERE [" + idField + "]=@id";

                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        if (UserRole == "user")
                        {
                            cmd.Parameters.Add("@imya", OleDbType.VarWChar).Value = txtImya.Text.Trim();
                            cmd.Parameters.Add("@familiya", OleDbType.VarWChar).Value = txtFamiliya.Text.Trim();
                            cmd.Parameters.Add("@phone", OleDbType.VarWChar).Value = txtPhone.Text.Trim();
                            cmd.Parameters.Add("@email", OleDbType.VarWChar).Value = txtEmail.Text.Trim();
                            cmd.Parameters.Add("@address", OleDbType.VarWChar).Value = txtAddress.Text.Trim();
                        }
                        else 
                        {
                            cmd.Parameters.Add("@name", OleDbType.VarWChar).Value = txtImya.Text.Trim();
                            cmd.Parameters.Add("@familiya", OleDbType.VarWChar).Value = txtFamiliya.Text.Trim();
                            cmd.Parameters.Add("@phone", OleDbType.VarWChar).Value = txtPhone.Text.Trim();
                        }

                        cmd.Parameters.Add("@id", OleDbType.Integer).Value = CurrentProfileID.Value;
                        int rows = cmd.ExecuteNonQuery();

                        if (rows > 0)
                        {
                            MessageBox.Show(" Профиль сохранен!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            lblWelcome.Text = $"Профиль: {txtImya.Text} {txtFamiliya.Text}";
                        }
                        else
                        {
                            MessageBox.Show(" Данные не изменились.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(" Ошибка сохранения: " + ex.Message);
            }
        }

        // Кнопка выхода
        private void btnLogout_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Вы действительно хотите выйти из аккаунта?",
                "Выход",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                this.Close(); 
            }
        }
    }
}