namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lblPaymentLabel = new System.Windows.Forms.Label();
            this.cmbPayment = new System.Windows.Forms.ComboBox();
            this.btnBookCar = new System.Windows.Forms.Button();
            this.btnDeleteCar = new System.Windows.Forms.Button();
            this.btnEditCar = new System.Windows.Forms.Button();
            this.btnAddCar = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnEditManager = new System.Windows.Forms.Button();
            this.btnDeleteManager = new System.Windows.Forms.Button();
            this.btnAddManager = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSortMonthYear = new System.Windows.Forms.TextBox();
            this.txtSortName = new System.Windows.Forms.TextBox();
            this.btnApplySort = new System.Windows.Forms.Button();
            this.btnCompleteSale = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.tabProfile = new System.Windows.Forms.TabPage();
            this.lblAddressLabel = new System.Windows.Forms.Label();
            this.lblEmailLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnSaveProfile = new System.Windows.Forms.Button();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.txtFamiliya = new System.Windows.Forms.TextBox();
            this.txtImya = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabProfile.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabProfile);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 505);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lblPaymentLabel);
            this.tabPage1.Controls.Add(this.cmbPayment);
            this.tabPage1.Controls.Add(this.btnBookCar);
            this.tabPage1.Controls.Add(this.btnDeleteCar);
            this.tabPage1.Controls.Add(this.btnEditCar);
            this.tabPage1.Controls.Add(this.btnAddCar);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 479);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Машины";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // lblPaymentLabel
            // 
            this.lblPaymentLabel.AutoSize = true;
            this.lblPaymentLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblPaymentLabel.Location = new System.Drawing.Point(439, 359);
            this.lblPaymentLabel.Name = "lblPaymentLabel";
            this.lblPaymentLabel.Size = new System.Drawing.Size(87, 13);
            this.lblPaymentLabel.TabIndex = 4;
            this.lblPaymentLabel.Text = "Способ оплаты:";
            // 
            // cmbPayment
            // 
            this.cmbPayment.FormattingEnabled = true;
            this.cmbPayment.Items.AddRange(new object[] {
            "наличные",
            "карта",
            "кредит"});
            this.cmbPayment.Location = new System.Drawing.Point(406, 375);
            this.cmbPayment.Name = "cmbPayment";
            this.cmbPayment.Size = new System.Drawing.Size(168, 21);
            this.cmbPayment.TabIndex = 3;
            // 
            // btnBookCar
            // 
            this.btnBookCar.Location = new System.Drawing.Point(620, 364);
            this.btnBookCar.Name = "btnBookCar";
            this.btnBookCar.Size = new System.Drawing.Size(143, 40);
            this.btnBookCar.TabIndex = 2;
            this.btnBookCar.Text = "Забронировать";
            this.btnBookCar.UseVisualStyleBackColor = true;
            this.btnBookCar.Click += new System.EventHandler(this.btnBookCar_Click);
            // 
            // btnDeleteCar
            // 
            this.btnDeleteCar.Location = new System.Drawing.Point(383, 359);
            this.btnDeleteCar.Name = "btnDeleteCar";
            this.btnDeleteCar.Size = new System.Drawing.Size(143, 40);
            this.btnDeleteCar.TabIndex = 5;
            this.btnDeleteCar.Text = "Удалить машину";
            this.btnDeleteCar.UseVisualStyleBackColor = true;
            this.btnDeleteCar.Click += new System.EventHandler(this.btnDeleteCar_Click);
            // 
            // btnEditCar
            // 
            this.btnEditCar.Location = new System.Drawing.Point(220, 359);
            this.btnEditCar.Name = "btnEditCar";
            this.btnEditCar.Size = new System.Drawing.Size(143, 40);
            this.btnEditCar.TabIndex = 6;
            this.btnEditCar.Text = "Редактировать";
            this.btnEditCar.UseVisualStyleBackColor = true;
            this.btnEditCar.Click += new System.EventHandler(this.btnEditCar_Click);
            // 
            // btnAddCar
            // 
            this.btnAddCar.Location = new System.Drawing.Point(57, 359);
            this.btnAddCar.Name = "btnAddCar";
            this.btnAddCar.Size = new System.Drawing.Size(143, 40);
            this.btnAddCar.TabIndex = 1;
            this.btnAddCar.Text = "Добавить машину";
            this.btnAddCar.UseVisualStyleBackColor = true;
            this.btnAddCar.Click += new System.EventHandler(this.btnAddCar_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(786, 344);
            this.dataGridView1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnEditManager);
            this.tabPage2.Controls.Add(this.btnDeleteManager);
            this.tabPage2.Controls.Add(this.btnAddManager);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(792, 479);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Менеджеры";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnEditManager
            // 
            this.btnEditManager.Location = new System.Drawing.Point(594, 365);
            this.btnEditManager.Name = "btnEditManager";
            this.btnEditManager.Size = new System.Drawing.Size(143, 42);
            this.btnEditManager.TabIndex = 3;
            this.btnEditManager.Text = "Изменить";
            this.btnEditManager.UseVisualStyleBackColor = true;
            this.btnEditManager.Click += new System.EventHandler(this.btnEditManager_Click);
            // 
            // btnDeleteManager
            // 
            this.btnDeleteManager.Location = new System.Drawing.Point(329, 365);
            this.btnDeleteManager.Name = "btnDeleteManager";
            this.btnDeleteManager.Size = new System.Drawing.Size(143, 42);
            this.btnDeleteManager.TabIndex = 2;
            this.btnDeleteManager.Text = "Удалить";
            this.btnDeleteManager.UseVisualStyleBackColor = true;
            this.btnDeleteManager.Click += new System.EventHandler(this.btnDeleteManager_Click);
            // 
            // btnAddManager
            // 
            this.btnAddManager.Location = new System.Drawing.Point(71, 365);
            this.btnAddManager.Name = "btnAddManager";
            this.btnAddManager.Size = new System.Drawing.Size(143, 42);
            this.btnAddManager.TabIndex = 1;
            this.btnAddManager.Text = "Добавить менеджера";
            this.btnAddManager.UseVisualStyleBackColor = true;
            this.btnAddManager.Click += new System.EventHandler(this.btnAddManager_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(3, 3);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(793, 344);
            this.dataGridView2.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.label4);
            this.tabPage3.Controls.Add(this.txtSortMonthYear);
            this.tabPage3.Controls.Add(this.txtSortName);
            this.tabPage3.Controls.Add(this.btnApplySort);
            this.tabPage3.Controls.Add(this.btnCompleteSale);
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(792, 479);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Продажи";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 385);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(168, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Месяц и год продажи (мм.гггг):";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 350);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(147, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Имя/Фамилия менеджера:";
            // 
            // txtSortMonthYear
            // 
            this.txtSortMonthYear.Location = new System.Drawing.Point(20, 401);
            this.txtSortMonthYear.Name = "txtSortMonthYear";
            this.txtSortMonthYear.Size = new System.Drawing.Size(265, 20);
            this.txtSortMonthYear.TabIndex = 5;
            // 
            // txtSortName
            // 
            this.txtSortName.Location = new System.Drawing.Point(20, 364);
            this.txtSortName.Name = "txtSortName";
            this.txtSortName.Size = new System.Drawing.Size(265, 20);
            this.txtSortName.TabIndex = 4;
            // 
            // btnApplySort
            // 
            this.btnApplySort.Location = new System.Drawing.Point(405, 378);
            this.btnApplySort.Name = "btnApplySort";
            this.btnApplySort.Size = new System.Drawing.Size(158, 43);
            this.btnApplySort.TabIndex = 3;
            this.btnApplySort.Text = "Сортировать";
            this.btnApplySort.UseVisualStyleBackColor = true;
            this.btnApplySort.Click += new System.EventHandler(this.btnApplySort_Click);
            // 
            // btnCompleteSale
            // 
            this.btnCompleteSale.Location = new System.Drawing.Point(604, 378);
            this.btnCompleteSale.Name = "btnCompleteSale";
            this.btnCompleteSale.Size = new System.Drawing.Size(158, 43);
            this.btnCompleteSale.TabIndex = 1;
            this.btnCompleteSale.Text = "Завершить сделку";
            this.btnCompleteSale.UseVisualStyleBackColor = true;
            this.btnCompleteSale.Click += new System.EventHandler(this.btnCompleteSale_Click);
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(3, 3);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.Size = new System.Drawing.Size(786, 344);
            this.dataGridView3.TabIndex = 0;
            // 
            // tabProfile
            // 
            this.tabProfile.Controls.Add(this.lblAddressLabel);
            this.tabProfile.Controls.Add(this.lblEmailLabel);
            this.tabProfile.Controls.Add(this.label3);
            this.tabProfile.Controls.Add(this.label2);
            this.tabProfile.Controls.Add(this.label1);
            this.tabProfile.Controls.Add(this.lblWelcome);
            this.tabProfile.Controls.Add(this.btnLogout);
            this.tabProfile.Controls.Add(this.btnSaveProfile);
            this.tabProfile.Controls.Add(this.txtAddress);
            this.tabProfile.Controls.Add(this.txtEmail);
            this.tabProfile.Controls.Add(this.txtPhone);
            this.tabProfile.Controls.Add(this.txtFamiliya);
            this.tabProfile.Controls.Add(this.txtImya);
            this.tabProfile.Location = new System.Drawing.Point(4, 22);
            this.tabProfile.Name = "tabProfile";
            this.tabProfile.Padding = new System.Windows.Forms.Padding(3);
            this.tabProfile.Size = new System.Drawing.Size(792, 479);
            this.tabProfile.TabIndex = 3;
            this.tabProfile.Text = "Профиль";
            this.tabProfile.UseVisualStyleBackColor = true;
            // 
            // lblAddressLabel
            // 
            this.lblAddressLabel.AutoSize = true;
            this.lblAddressLabel.Location = new System.Drawing.Point(188, 286);
            this.lblAddressLabel.Name = "lblAddressLabel";
            this.lblAddressLabel.Size = new System.Drawing.Size(41, 13);
            this.lblAddressLabel.TabIndex = 12;
            this.lblAddressLabel.Text = "Адрес:";
            // 
            // lblEmailLabel
            // 
            this.lblEmailLabel.AutoSize = true;
            this.lblEmailLabel.Location = new System.Drawing.Point(194, 237);
            this.lblEmailLabel.Name = "lblEmailLabel";
            this.lblEmailLabel.Size = new System.Drawing.Size(35, 13);
            this.lblEmailLabel.TabIndex = 11;
            this.lblEmailLabel.Text = "Email:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(174, 185);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Телефон:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(170, 131);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Фамилия:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(197, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Имя:";
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Location = new System.Drawing.Point(40, 19);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(35, 13);
            this.lblWelcome.TabIndex = 7;
            this.lblWelcome.Text = "label1";
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(512, 346);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(186, 47);
            this.btnLogout.TabIndex = 6;
            this.btnLogout.Text = "Выйти";
            this.btnLogout.UseMnemonic = false;
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnSaveProfile
            // 
            this.btnSaveProfile.Location = new System.Drawing.Point(117, 346);
            this.btnSaveProfile.Name = "btnSaveProfile";
            this.btnSaveProfile.Size = new System.Drawing.Size(186, 47);
            this.btnSaveProfile.TabIndex = 5;
            this.btnSaveProfile.Text = "Сохранить изменения";
            this.btnSaveProfile.UseVisualStyleBackColor = true;
            this.btnSaveProfile.Click += new System.EventHandler(this.btnSaveProfile_Click);
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(260, 283);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(304, 20);
            this.txtAddress.TabIndex = 4;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(260, 234);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(304, 20);
            this.txtEmail.TabIndex = 3;
            // 
            // txtPhone
            // 
            this.txtPhone.Location = new System.Drawing.Point(260, 182);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(304, 20);
            this.txtPhone.TabIndex = 2;
            // 
            // txtFamiliya
            // 
            this.txtFamiliya.Location = new System.Drawing.Point(260, 128);
            this.txtFamiliya.Name = "txtFamiliya";
            this.txtFamiliya.Size = new System.Drawing.Size(304, 20);
            this.txtFamiliya.TabIndex = 1;
            // 
            // txtImya
            // 
            this.txtImya.Location = new System.Drawing.Point(260, 76);
            this.txtImya.Name = "txtImya";
            this.txtImya.Size = new System.Drawing.Size(304, 20);
            this.txtImya.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 505);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "AutoS";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabProfile.ResumeLayout(false);
            this.tabProfile.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.TabPage tabProfile;
        private System.Windows.Forms.Button btnSaveProfile;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.TextBox txtFamiliya;
        private System.Windows.Forms.TextBox txtImya;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblAddressLabel;
        private System.Windows.Forms.Label lblEmailLabel;
        private System.Windows.Forms.Button btnAddCar;
        private System.Windows.Forms.Button btnEditCar;
        private System.Windows.Forms.Button btnDeleteCar;
        private System.Windows.Forms.ComboBox cmbPayment;
        private System.Windows.Forms.Button btnBookCar;
        private System.Windows.Forms.Label lblPaymentLabel;
        private System.Windows.Forms.Button btnEditManager;
        private System.Windows.Forms.Button btnDeleteManager;
        private System.Windows.Forms.Button btnAddManager;
        private System.Windows.Forms.Button btnApplySort;
        private System.Windows.Forms.Button btnCompleteSale;
        private System.Windows.Forms.TextBox txtSortMonthYear;
        private System.Windows.Forms.TextBox txtSortName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
    }
}