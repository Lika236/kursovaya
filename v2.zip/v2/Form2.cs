using System;
using System.Data.OleDb;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class LoginForm : Form
    {
        string connectionString =
            @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Автосалон.mdb;";

        public LoginForm()
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Авторизация";
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    // 1. Теперь запрашиваем и Role, и ProfileID
                    string query = "SELECT [Role], [ProfileID] FROM [Пользователи] WHERE [Login]=@login AND [Password]=@pass";
                    OleDbCommand cmd = new OleDbCommand(query, conn);
                    cmd.Parameters.AddWithValue("@login", textBoxLogin.Text.Trim());
                    cmd.Parameters.AddWithValue("@pass", textBoxPassword.Text.Trim());

                    OleDbDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        // Читаем роль
                        string role = reader["Role"].ToString().Trim().ToLower();

                        // Читаем ProfileID (и проверяем, не пустой ли он в базе)
                        object dbProfileId = reader["ProfileID"];
                        int? profileId = (dbProfileId == DBNull.Value) ? (int?)null : Convert.ToInt32(dbProfileId);

                        MessageBox.Show("Вход выполнен успешно!", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        this.Hide();
                        Form1 main = new Form1();

                        // 2. Передаем данные в главную форму
                        main.UserRole = role;
                        main.CurrentProfileID = profileId; // ← ВОТ ЭТО ГЛАВНОЕ ИСПРАВЛЕНИЕ

                        main.ShowDialog();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Неверный логин или пароль.", "Ошибка входа",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка соединения: " + ex.Message, "Ошибка",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void buttonRegister_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 reg = new Form3();
            reg.ShowDialog();
            this.Show();
        }
    }
}