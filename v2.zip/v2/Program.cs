﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            while (true)
            {
                using (var loginForm = new LoginForm())
                {
                    if (loginForm.ShowDialog() != DialogResult.OK)
                        break;

                    using (var mainForm = new Form1())
                    {
                        mainForm.UserRole = loginForm.UserRole;
                        mainForm.CurrentProfileID = loginForm.CurrentProfileID;
                        mainForm.ShowDialog();

                        if (!mainForm.ShouldReturnToLogin)
                            break;
                    }
                }
            }
        }
    }
}