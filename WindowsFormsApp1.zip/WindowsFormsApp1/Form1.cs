﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        string connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\Автосалон.mdb;";
        public string UserRole { get; set; }
        public int? CurrentProfileID { get; set; }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            

            //  ТАБЛИЦЫ 
            SetupGrid(dataGridView1);
            SetupGrid(dataGridView2);
            SetupGrid(dataGridView3);
            LoadAllData();

            //  ПРОФИЛЬ
            if (UserRole == "admin")
            {
                lblWelcome.Text = "Панель Администратора";
                DisableProfileFields();
            }
            else if (CurrentProfileID.HasValue)
            {
                LoadProfileData(); // Загружаем все данные при входе
            }
        }

        private void DisableProfileFields()
        {
            txtImya.Enabled = false;
            txtFamiliya.Enabled = false;
            txtPhone.Enabled = false;
            txtEmail.Enabled = false;
            txtAddress.Enabled = false;
            btnSaveProfile.Enabled = false;
            btnSaveProfile.Text = "Недоступно";
        }

        // ЗАГРУЗКА ПРОФИЛЯ
        private void LoadProfileData()
        {
            if (UserRole == "admin") return;

            try
            {
                string tableName = UserRole == "user" ? "Klienty" : "Manager";
                string idField = UserRole == "user" ? "KlientID" : "ManagerID";

                string query = UserRole == "user"
                    ? $"SELECT Imya, Familiya, Number, Email, Address FROM [{tableName}] WHERE [{idField}] = @id"
                    : $"SELECT [Name manager], Familiya, Kontakt FROM [{tableName}] WHERE [{idField}] = @id";

                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", CurrentProfileID.Value);
                        using (OleDbDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                if (UserRole == "user")
                                {
                                    txtImya.Text = reader["Imya"]?.ToString() ?? "";
                                    txtFamiliya.Text = reader["Familiya"]?.ToString() ?? ""; 
                                    txtPhone.Text = reader["Number"]?.ToString() ?? "";
                                    txtEmail.Text = reader["Email"]?.ToString() ?? "";
                                    txtAddress.Text = reader["Address"]?.ToString() ?? "";
                                    lblWelcome.Text = $"Профиль: {reader["Imya"]} {reader["Familiya"]}";
                                }
                                else 
                                {
                                    txtImya.Text = reader["Name manager"]?.ToString() ?? "";
                                    txtFamiliya.Text = reader["Familiya"]?.ToString() ?? ""; 
                                    txtPhone.Text = reader["Kontakt"]?.ToString() ?? "";
                                    lblWelcome.Text = $"Профиль: {reader["Name manager"]} {reader["Familiya"]}";

                                    txtEmail.Visible = false;
                                    txtAddress.Visible = false;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки профиля: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //  СОХРАНЕНИЕ ПРОФИЛЯ
        private void btnSaveProfile_Click(object sender, EventArgs e)
        {
            if (UserRole == "admin")
            {
                MessageBox.Show("У администратора нет редактируемого профиля.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (!CurrentProfileID.HasValue)
            {
                MessageBox.Show("Ошибка: не найден ID профиля!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                string tableName = UserRole == "user" ? "Klienty" : "Manager";
                string idField = UserRole == "user" ? "KlientID" : "ManagerID";

          
                string query = UserRole == "user"
                    ? "UPDATE [Klienty] SET [Imya]=@imya, [Familiya]=@familiya, [Number]=@phone, [Email]=@email, [Address]=@address WHERE [KlientID]=@id"
                    : "UPDATE [Manager] SET [Name manager]=@name, [Familiya]=@familiya, [Kontakt]=@phone WHERE [ManagerID]=@id";

                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        if (UserRole == "user")
                        {
                            cmd.Parameters.AddWithValue("@imya", txtImya.Text.Trim());
                            cmd.Parameters.AddWithValue("@familiya", txtFamiliya.Text.Trim());
                            cmd.Parameters.AddWithValue("@phone", txtPhone.Text.Trim());
                            cmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim());
                            cmd.Parameters.AddWithValue("@address", txtAddress.Text.Trim());
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue("@name", txtImya.Text.Trim());
                            cmd.Parameters.AddWithValue("@familiya", txtFamiliya.Text.Trim());
                            cmd.Parameters.AddWithValue("@phone", txtPhone.Text.Trim());
                        }

                        cmd.Parameters.AddWithValue("@id", CurrentProfileID.Value);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Данные профиля успешно сохранены!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            lblWelcome.Text = $"Профиль: {txtImya.Text} {txtFamiliya.Text}";
                        }
                        else
                        {
                            MessageBox.Show("Данные не были изменены.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения: " + ex.Message + "\n\nДетали: " + ex.InnerException?.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ВЫХОД
        private void btnLogout_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы уверены, что хотите выйти?", "Выход", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                this.Close();
        }

        private void SetupGrid(DataGridView grid)
        {
            grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grid.AllowUserToAddRows = false;
            grid.ReadOnly = true;
        }

        private void LoadAllData()
        {
          
            string sqlCars = "SELECT Marka, Model, [God Vipyska], Color, Price FROM Car";
            LoadTable(sqlCars, dataGridView1);

            string sqlManagers = "SELECT [Name manager], Familiya, Kontakt FROM [Manager]";
            LoadTable(sqlManagers, dataGridView2);

            string sqlSales = "SELECT c.Marka & ' ' & c.Model AS Mashina, " +
                              "k.Imya & ' ' & k.Familiya AS Pokupatel, " +
                              "m.[Name manager] & ' ' & m.Familiya AS Manager, " +
                              "p.[Data prodazhi], p.[Cymma prodazhi], p.[Cposob oplati] " +
                              "FROM ((Prodazhi p " +
                              "INNER JOIN Car c ON p.CarID = c.CarID) " +
                              "INNER JOIN Klienty k ON p.KlientID = k.KlientID) " +
                              "INNER JOIN [Manager] m ON p.ManagerID = m.ManagerID " +
                              "ORDER BY p.[Data prodazhi] DESC";
            LoadTable(sqlSales, dataGridView3);
        }

        private void LoadTable(string query, DataGridView grid)
        {
            try
            {
                grid.DataSource = null;
                grid.Columns.Clear();

                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    using (OleDbDataAdapter adapter = new OleDbDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        grid.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка:\n" + query + "\n\n" + ex.Message, "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadAllData();
        }
    }
}